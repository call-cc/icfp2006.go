
void antfarm (string);

extern int DO_MOVIE;
