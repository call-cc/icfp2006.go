void main () print ("hello world\n");
