int main() {
  switch (4 + 3) {
	case 8:
		print ("almost... but ");
	default:
		print ("nope\n");
		break;
	case 9:
		print ("right!\n");
	}

	return 0;
}
