package edu.cmu.cs.homework7.um;

public interface StatusIndicator {
    public void setStatus(String s);
    public void clearStatus();
}
