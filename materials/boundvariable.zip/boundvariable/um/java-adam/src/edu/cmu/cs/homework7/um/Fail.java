package edu.cmu.cs.homework7.um;

public class Fail extends RuntimeException {

    public Fail(String string) {
        super(string);
    }
}
